package simulations

import baseConfig.BaseSimulation
import io.gatling.core.Predef._
import io.gatling.http.Predef._

import scala.concurrent.duration.DurationInt

class dndperftests extends BaseSimulation {



def getDndTests() = {
    repeat(9) {
      exec(flushHttpCache)

      exec(http("DnD Perf Test method")
        .get("https://ac1752ff16b6711e9b0a70af7583652d-2100128123.us-west-2.elb.amazonaws.com")
        .virtualHost("dev.dnd.wizards.com")

        .check(status.is(200))) // check for a specific status
        .exec { session => println(session); session } // parameter for the orgId goes here
        .pause(1)

    }
  }

  val scn = scenario("DnD Perf Tests")

    .forever() {exec(getDndTests())

      .pause(5)
      //.pause(5)
    }

  // Run for a fixed duration
  setUp(
    scn.inject(
      nothingFor(5 seconds),
      //atOnceUsers(300000),
      rampUsers(300000) over (300 second)
      //rampUsers(1) during  (20 second)
    ).protocols(httpProtocol.inferHtmlResources()))
    .maxDuration(5 minute)

}

