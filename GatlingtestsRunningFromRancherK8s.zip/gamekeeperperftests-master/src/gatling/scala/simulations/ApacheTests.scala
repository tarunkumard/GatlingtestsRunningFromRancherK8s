package simulations

import baseConfig.BaseSimulation
import io.gatling.core.Predef._
import io.gatling.http.Predef._

import scala.concurrent.duration.DurationInt

class ApacheTests extends BaseSimulation {




  def getApacheTests() = {
repeat(500){
   
      exec(flushHttpCache)

      exec(http("Apache Test method")



        .get("http://testwebserverclb-24790314.us-west-2.elb.amazonaws.com/")


        .check(status.in(200,304))) // check for a specific status
        .exec { session => println(session); session } // parameter for the orgId goes here
        .pause(2)

}
  
  }



  val scn = scenario("Apache Perf Tests")

    .forever() {exec(getApacheTests())

      .pause(2)
      //.pause(5)
    }

  // Run for a fixed duration
  setUp(
    scn.inject(
      nothingFor(2 seconds),
      //atOnceUsers(99099),
      rampUsers(2100) over (700 seconds)
      //constantUsersPerSec(3900) during (900 seconds)
      //rampUsers(1) during  (20 second)
    ).protocols(httpProtocol.inferHtmlResources()))
    .maxDuration(700 seconds)

}

