package simulations

import baseConfig.BaseSimulation
import com.jayway.jsonpath.JsonPath
import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._
import scala.concurrent.forkjoin.ThreadLocalRandom
import scala.language.postfixOps
import scala.math._

import scala.concurrent.duration.DurationInt
import scala.io.Source


class gamekeeper extends BaseSimulation {

  val uri03 = "https://api.platform.wizards.com"

  val headers_0 = Map(
    "Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "Accept-Encoding" -> "gzip, deflate, br",
    "Accept-Language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "Upgrade-Insecure-Requests" -> "1",
    "User-Agent" -> "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36")

  val headers_1 = Map("User-Agent" -> "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36")

  val headers_7 = Map(
    "Access-Control-Request-Headers" -> "authorization",
    "Access-Control-Request-Method" -> "POST",
    "Origin" -> "https://api.tabletop-stage.tiamat-origin.cloud",
    "User-Agent" -> "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36")

  val headers_8 = Map(
    "Accept" -> "application/json, text/plain, */*",
    "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://api.tabletop-stage.tiamat-origin.cloud",
    "User-Agent" -> "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36")

  val headers_10 = Map("Content-Type" -> "application/json","Authorization" -> "${token_type} + ${access_token}" )

  val usersDataSource=jsonFile("/opt/src/gatling/resources/data/input-gamekeeper.json").circular
  val nameDataSource=jsonFile("/opt/src/gatling/resources/data/input-gamekeeper-StringBody.json").random
  var idNumbers=(1000020 to 1000030).iterator





  private def getProperty(propertyName: String, defaultValue: String) = {
    Option(System.getenv(propertyName))
      .orElse(Option(System.getProperty(propertyName)))
      .getOrElse(defaultValue)
  }
  // now specify the properties
  //def userCount: Int = getProperty("USERS", "100").toInt

  val source: String = Source.fromFile("/opt/src/gatling/resources/data/input-gamekeeper.json").getLines.mkString
  def userCount: Int  = JsonPath.parse(source).read("$.[0].user")
  def testDuration: Int  = JsonPath.parse(source).read("$.[0].testDuration")
  def rampDuration: Int  = JsonPath.parse(source).read("$.[0].rampDuration")


  // print out the properties at the start of the test
  before {
    println(s"Running test with ${userCount} users")
    println(s"Ramping users over ${rampDuration} seconds")
    println(s"Total Test duration: ${testDuration} seconds")
  }

  def getNextOrgId()=
  {

    if(!idNumbers.hasNext)
      idNumbers=(1000020 to 1000030).iterator
    Map("orgId"->idNumbers.next())
  }



  val customFeeder=Iterator.continually(getNextOrgId())






  def createEventRound()={
    repeat(990000000){


      exec(flushHttpCache)
      feed(customFeeder)
        .exec(http("CreateEventRound-GameKeeper")

          //exec(http("CreateEventRound-GameKeeper")
          .post("https://api.tabletop-stage.tiamat-origin.cloud/dev/gamekeeper/Round")
          .headers(headers_10)


           .body(StringBody(
           """
             |{
             |  "eventId": ${orgId},
             |  "roundStart": "2019-04-16T18:22:50.388Z",
             |  "roundEnd": "2019-04-16T18:22:50.388Z",
             |  "currentTime": "2019-04-16T18:22:50.388Z",
             |  "roundNumber": 1,
             |  "matches": [
             |    {
             |      "matchId": 0,
             |      "isBye": true,
             |      "tableNumber": "string",
             |      "teams": [
             |        {
             |          "teamId": 0,
             |          "teamName": "string",
             |          "players": [
             |            {
             |              "personaId": "string",
             |              "displayName": "string"
             |            }
             |          ]
             |        }
             |      ]
             |    }
             |  ]
             |}
        """.stripMargin)).asJSON

          .check(status.in(200,201))//checkforaspecificstatus
          .check(jsonPath(path="$.roundNumber").is("1"))
          .check(jsonPath(path="$.eventId").saveAs(key="eventId")))//checkforaspecificstatus
         // .check(jsonPath(path="$.displayName").saveAs(key="displayName")))//checkforaspecificstatus
        .exec{session=>println(session);session}//parameterfortheorgIdgoeshere
        .pause(1)

    }
  }


  def createRoundResult()={
    repeat(990000000){


      exec(flushHttpCache)
      feed(customFeeder)
        .exec(http("Create Round Result")

          //exec(http("CreateEventRound-GameKeeper")
          .post("https://api.tabletop-stage.tiamat-origin.cloud/dev/gamekeeper/Round/Result")
          .headers(headers_10)


          .body(StringBody(
            """
              |[
              |  {
              |    "gameNumber": 0,
              |    "isFinal": false,
              |    "isTO": true,
              |    "isBye": true,
              |    "wins": 0,
              |    "losses": 0,
              |    "draws": 0,
              |    "teamId": 1285,
              |    "matchId": 1286
              |  }
              |]
            """.stripMargin)).asJSON

          .check(status.in(200,201)))//checkforaspecificstatus
          //.check(jsonPath(path="$.wins").is("0")))
         // .check(jsonPath(path="$.eventId").saveAs(key="eventId")))//checkforaspecificstatus
        // .check(jsonPath(path="$.displayName").saveAs(key="displayName")))//checkforaspecificstatus
        .exec{session=>println(session);session}//parameterfortheorgIdgoeshere
        .pause(1)

    }
  }


  def getEventRound()={
    repeat(990000000){


      exec(flushHttpCache)
      feed(customFeeder)
        .exec(http("Get Current Round")

          .get("https://api.tabletop-stage.tiamat-origin.cloud/dev/gamekeeper/Round/Event/${orgId}/CurrentRound")
          .headers(headers_10)

          .check(status.is(200)))//checkforaspecificstatus
         // .check(jsonPath(path="$.eventId").saveAs(key="eventId")))//checkforaspecificstatus
        // .check(jsonPath(path="$.displayName").saveAs(key="displayName")))//checkforaspecificstatus
        .exec{session=>println(session);session}//parameterfortheorgIdgoeshere
        .pause(1)

    }
  }
  // add a scenario



  val scenario2 = scenario("Game Keeper Post Orgs ")
    .exec(http("Event-Reservations-Web-Image-Login")
      .get("https://api.tabletop-stage.tiamat-origin.cloud/dev/event-reservations-web/img/loading.dfbfd678.svg")
      .headers(headers_1)
      .resources(http("Http Header Token Authentication Url")
        .options(uri03 + "/auth/oauth/token")
        .headers(headers_7),
        http("Token Generation Url For Post")
          .post(uri03 + "/auth/oauth/token")
          .headers(headers_8)
          .formParam("grant_type", "password")
          .formParam("username", "TableTopEng@wizards.com")
          .formParam("password", "fJC2RuVdvmHB")
          .basicAuth("ikrwugh3871ghw8rgn7q83gh","NbnEEqmDLSfno315o87ghFGYr3jybtzbi76sr")
          .check(jsonPath("$.access_token").exists.saveAs("access_token"))
          .check(jsonPath("$.token_type").exists.saveAs("token_type"))





      ))
    .forever() { // add in the forever() method - users now loop forever

      exec(createRoundResult())



    }

  val scenario1 = scenario("Game Keeper Get Events ")
    .exec(http("Event-Reservations-Web-Image-Login")
      .get("https://api.tabletop-stage.tiamat-origin.cloud/dev/event-reservations-web/img/loading.dfbfd678.svg")
      .headers(headers_1)
      .resources(http("Http Header Token Authentication Url")
        .options(uri03 + "/auth/oauth/token")
        .headers(headers_7),
        http("Token Generation Url For Post")
          .post(uri03 + "/auth/oauth/token")
          .headers(headers_8)
          .formParam("grant_type", "password")
          .formParam("username", "TableTopEng@wizards.com")
          .formParam("password", "fJC2RuVdvmHB")
          .basicAuth("ikrwugh3871ghw8rgn7q83gh","NbnEEqmDLSfno315o87ghFGYr3jybtzbi76sr")
          .check(jsonPath("$.access_token").exists.saveAs("access_token"))
          .check(jsonPath("$.token_type").exists.saveAs("token_type"))





      ))
    .forever() { // add in the forever() method - users now loop forever

      exec(getEventRound())
    }

  val scenario3 = scenario("Game Keeper Post Orgs To Fetch Get CurrentRounds ")
    .exec(http("Event-Reservations-Web-Image-Login")
      .get("https://api.tabletop-stage.tiamat-origin.cloud/dev/event-reservations-web/img/loading.dfbfd678.svg")
      .headers(headers_1)
      .resources(http("Http Header Token Authentication Url")
        .options(uri03 + "/auth/oauth/token")
        .headers(headers_7),
        http("Token Generation Url For Post")
          .post(uri03 + "/auth/oauth/token")
          .headers(headers_8)
          .formParam("grant_type", "password")
          .formParam("username", "TableTopEng@wizards.com")
          .formParam("password", "fJC2RuVdvmHB")
          .basicAuth("ikrwugh3871ghw8rgn7q83gh","NbnEEqmDLSfno315o87ghFGYr3jybtzbi76sr")
          .check(jsonPath("$.access_token").exists.saveAs("access_token"))
          .check(jsonPath("$.token_type").exists.saveAs("token_type"))





      ))
    .forever() { // add in the forever() method - users now loop forever
      exec(createEventRound())



    }

  // setup the load profile
  // example command line: ./gradlew gatlingRun-simulations.RuntimeParameters -DUSERS=10 -DRAMP_DURATION=5 -DDURATION=30
  setUp(

    scenario2.inject(
      nothingFor(5 seconds),
      rampUsers(userCount) over ( rampDuration ))
      .protocols(httpConf),
    scenario3.inject(
      nothingFor(5 seconds),
      rampUsers(userCount) over ( rampDuration ))
      .protocols(httpConf),
    scenario1.inject(
      nothingFor(5 seconds),
      rampUsers(userCount) over ( rampDuration ))
      .protocols(httpConf))


    .maxDuration(testDuration)
}

