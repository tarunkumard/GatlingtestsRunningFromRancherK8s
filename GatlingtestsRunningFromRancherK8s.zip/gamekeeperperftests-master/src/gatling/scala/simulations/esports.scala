package simulations

import baseConfig.BaseSimulation
import com.jayway.jsonpath.JsonPath
import io.gatling.core.Predef._
import io.gatling.http.Predef._

import scala.concurrent.duration.DurationInt
import scala.io.Source

class esports extends BaseSimulation {



  val usersDataSource=jsonFile("input-post.json").circular
  val nameDataSource=jsonFile("input-get.json").random
  var idNumbers=(21 to 33).iterator

  val headers_0 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "if-modified-since" -> "Tue, 12 Mar 2019 19:33:17 GMT",
    "if-none-match" -> "93e438839c6b04e010a23e212a354d88:1552419220.66978",
    "upgrade-insecure-requests" -> "1")

  val headers_2 = Map("Origin" -> "https://stage.mtgesports.com")

  val headers_8 = Map(
    "Accept" -> "application/json, text/plain, */*",
    "Origin" -> "https://stage.mtgesports.com")

  val headers_72 = Map(
    "Access-Control-Request-Headers" -> "authorization,x-contentful-user-agent",
    "Access-Control-Request-Method" -> "GET",
    "Origin" -> "https://stage.mtgesports.com")

  val headers_73 = Map(
    "Accept" -> "application/json, text/plain, */*",
    "Origin" -> "https://stage.mtgesports.com",
    "X-Contentful-User-Agent" -> "sdk contentful.js/0.0.0-determined-by-semantic-release; platform browser; os Windows;",
    "authorization" -> "Bearer dcc180e468048c95a5ebb91ef663e19c8520152228ffa29fced12414fe462697")

  val headers_108 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "upgrade-insecure-requests" -> "1")

  val headers_132 = Map("Origin" -> "https://player.twitch.tv")

  val headers_133 = Map(
    "Access-Control-Request-Headers" -> "client-id",
    "Access-Control-Request-Method" -> "GET",
    "Origin" -> "https://player.twitch.tv")

  val headers_134 = Map(
    "Access-Control-Request-Headers" -> "client-id,content-type",
    "Access-Control-Request-Method" -> "POST",
    "Origin" -> "https://player.twitch.tv")

  val headers_141 = Map(
    "Accept" -> "application/vnd.twitchtv.v3+json",
    "Client-ID" -> "jzkbprff40iqj646a697cyrvl0zt2m6",
    "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://player.twitch.tv")

  val headers_143 = Map(
    "Client-ID" -> "jzkbprff40iqj646a697cyrvl0zt2m6",
    "Content-Type" -> "application/json",
    "Origin" -> "https://player.twitch.tv")

  val headers_147 = Map(
    "Client-ID" -> "jzkbprff40iqj646a697cyrvl0zt2m6",
    "Origin" -> "https://player.twitch.tv")

  val headers_148 = Map(
    "Access-Control-Request-Headers" -> "content-type,x-requested-with",
    "Access-Control-Request-Method" -> "POST",
    "Origin" -> "https://player.twitch.tv")

  val headers_149 = Map(
    "Content-Type" -> "application/json",
    "Origin" -> "https://player.twitch.tv",
    "X-Requested-With" -> "XMLHttpRequest")

  val headers_152 = Map(
    "accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "accept-encoding" -> "gzip, deflate, br",
    "accept-language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "upgrade-insecure-requests" -> "1",
    "x-client-data" -> "CKa1yQEIj7bJAQijtskBCMS2yQEIqZ3KAQioo8oBCLGnygEIv6fKAQjiqMoBGLeYygEY+aXKAQ==")

  val headers_154 = Map(
    "Accept" -> "application/x-mpegURL, application/vnd.apple.mpegurl, application/json, text/plain",
    "Origin" -> "https://player.twitch.tv")

  val headers_156 = Map(
    "Accept" -> "application/vnd.twitchtv.v5+json",
    "Client-ID" -> "jzkbprff40iqj646a697cyrvl0zt2m6",
    "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://player.twitch.tv")

  val headers_157 = Map(
    "Content-type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://player.twitch.tv")

  val uri01 = "https://stage.mtgesports.com"
  val uri03 = "https://images.ctfassets.net/ryplwhabvmmk"
  val uri04 = "https://polyfill.io/v3/polyfill.min.js"
  val uri05 = "https://client-event-reporter.twitch.tv/v1/stats"
  val uri06 = "https://source.unsplash.com"
  val uri07 = "https://api.twitch.tv"
  val uri08 = "https://images.unsplash.com"
  val uri09 = "https://imasdk.googleapis.com/js/core/bridge3.285.0_en.html"
  val uri10 = "https://usher.ttvnw.net/api/channel/hls/reiderrabbit.m3u8"
  val uri11 = "https://player.twitch.tv"
  val uri12 = "https://adservice.google.com/adsid/integrator.js"
  val uri13 = "https://fonts.gstatic.com/s/opensans/v15"
  val uri14 = "https://www.twitch.tv/experiments.json"
  val uri15 = "https://countess.twitch.tv/ping.gif"
  val uri16 = "https://video-edge-6e60dd.sjc02.hls.ttvnw.net/v1/segment/CmsX29NQ1H5y99gILVSrra08m1e3LZFXPcahxLMuv9UW6HhUgDZZ8sNCZ59alrJkRoJnvDIy42_5RULQAiMXuDTjsd1_tZtbsLuKK6O7CrgH_XWNuzmhOTrQqmvZck5Vb_HBSDr7U7P5YrUe_8GD1xwugDlajLcaH_2SmuLGmnJX_YdTJZKMqepDbhbcYU67U2MKm5_AJJ2aJKBg8bB2Vj2uj71HAT5EzsWeb-d1CU79Kdfijxt_TPIh7vBHJqPfG-lGtK7Z9cQmzkrfeRV8OncDD7nvrY7TZFCswqXsiuymdLLajhs_hyZUDde7P9jopCy1JAOG3D3ORCWaUup8_eXJHBqwnuRd_LkZLrl4RvTF7gjGKjzqzMX7sZKQhKRhQCJlO3aeDPtUiGCd5iNqATLbQkgQXag_59Xy7Vl5gVp086fbC3gHrIpACJoUilqK3-f2x4yiY2LKOkqrbaOBPp56cEcIQR8JSdirchXG55hdlLrZra1lzPCqsOhJNlx7EjIQcZ6RyGPQDTYtnw9DylCv9v4lu89Mu67n5c38EnhZcMxDU0Q152xPxeZkwo-GjeRsqEbchT8n6a9u3xrQQ7yUBV6Pk2luPxUTGthn3rJlpO4oIH2wplb-ImCyfPgiQsydBwLE7A1tGH35Vnf9UzUaCdtdt8gIz725Y9TtStVbNeYRQBl2N6H6LV7t1tIUc2peNVZCYAo9fBj3yjNHv_CQ2xIFEWKRBLLkEkLioMPhvRBVrmNAcAjQe2FO07PNY7-dwtmwZbA8OU5pkLxF7A.ts"
  val uri17 = "https://fonts.googleapis.com/css"
  val uri18 = "https://cvp.twitch.tv/2.9.2/wasmworker.min.wasm"



  // now specify the properties
  //def userCount: Int = getProperty("USERS", "100").toInt

  val source: String = Source.fromFile("src/gatling/resources/data/input-post.json").getLines.mkString
  def userCount: Int  = JsonPath.parse(source).read("$.[0].user")
  def testDuration: Int  = JsonPath.parse(source).read("$.[0].testDuration")
  def rampDuration: Int  = JsonPath.parse(source).read("$.[0].rampDuration")


  // print out the properties at the start of the test
  before {
    println(s"Running test with ${userCount} users")
    println(s"Ramping users over ${rampDuration} seconds")
    println(s"Total Test duration: ${testDuration} seconds")
  }



  def postSpecificOgreID()={
    repeat(10000){


      exec(flushHttpCache)
        .exec(http("request_0")
          .get(uri01 + "/")
          .headers(headers_0)
          .resources(http("request_1")
            .get(uri17 + "?family=Open+Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic"),
            http("request_2")
              .get(uri04 + "?features=default%2CArray.prototype.includes")
              .headers(headers_2),
            http("request_3")
              .get(uri13 + "/mem5YaGs126MiZpBA-UNirkOUuhpKKSTjw.woff2")
              .headers(headers_2),
            http("request_4")
              .get(uri13 + "/mem5YaGs126MiZpBA-UN8rsOUuhpKKSTjw.woff2")
              .headers(headers_2),
            http("request_5")
              .get(uri13 + "/mem5YaGs126MiZpBA-UN7rgOUuhpKKSTjw.woff2")
              .headers(headers_2),
            http("request_6")
              .get(uri13 + "/mem8YaGs126MiZpBA-UFVZ0bf8pkAg.woff2")
              .headers(headers_2),
            http("request_7")
              .get(uri01 + "/fonts/Beleren-Bold.woff2")
              .headers(headers_2)))
        .pause(1)
        .exec(http("request_8")
          .get(uri07 + "/kraken/streams/jirock?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
          .headers(headers_8)
          .resources(http("request_9")
            .get(uri07 + "/kraken/streams/javierdmagic?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
            .headers(headers_8),
            http("request_10")
              .get(uri07 + "/kraken/streams/g3rryt?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_11")
              .get(uri07 + "/kraken/streams/andreamengucci?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_12")
              .get(uri07 + "/kraken/streams/urlich0?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_13")
              .get(uri07 + "/kraken/streams/bens_MTG?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_14")
              .get(uri07 + "/kraken/streams/fffreakmtg?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_15")
              .get(uri07 + "/kraken/streams/mtgbbd?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_16")
              .get(uri07 + "/kraken/streams/cadu_romao?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_17")
              .get(uri07 + "/kraken/streams/efropoker?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_18")
              .get(uri07 + "/kraken/streams/yaya3_?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_19")
              .get(uri07 + "/kraken/streams/chauckster?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_20")
              .get(uri07 + "/kraken/streams/beena_oyaoya?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_21")
              .get(uri07 + "/kraken/streams/pvddr?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_22")
              .get(uri07 + "/kraken/streams/reiderrabbit?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_23")
              .get(uri07 + "/kraken/streams/andrewcuneo?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_24")
              .get(uri07 + "/kraken/streams/luissalvatto?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_25")
              .get(uri07 + "/kraken/streams/insaynehayne?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_26")
              .get(uri07 + "/kraken/streams/jrolfmtg?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_27")
              .get(uri07 + "/kraken/streams/owentmagic?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_28")
              .get(uri07 + "/kraken/streams/death_snow?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_29")
              .get(uri07 + "/kraken/streams/lucas_esper_berthoud?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_30")
              .get(uri07 + "/kraken/streams/r0310?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_31")
              .get(uri07 + "/kraken/streams/leearson?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_32")
              .get(uri07 + "/kraken/streams/sethmanfield?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_33")
              .get(uri07 + "/kraken/streams/kbol_?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_34")
              .get(uri07 + "/kraken/streams/martinjuza?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_35")
              .get(uri07 + "/kraken/streams/kanister_mtg?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_36")
              .get(uri07 + "/kraken/streams/msigrist83?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_37")
              .get(uri07 + "/kraken/streams/insaynehayne?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_38")
              .get(uri07 + "/kraken/streams/g3rryt?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_39")
              .get(uri07 + "/kraken/streams/jirock?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_40")
              .get(uri07 + "/kraken/streams/javierdmagic?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_41")
              .get(uri07 + "/kraken/streams/urlich0?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_42")
              .get(uri07 + "/kraken/streams/matthewlnass?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_43")
              .get(uri07 + "/kraken/streams/shahar_shenhar?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_44")
              .get(uri07 + "/kraken/streams/HueyWJ?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_45")
              .get(uri07 + "/kraken/streams/andreamengucci?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_46")
              .get(uri07 + "/kraken/streams/bens_MTG?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_47")
              .get(uri07 + "/kraken/streams/fffreakmtg?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_48")
              .get(uri07 + "/kraken/streams/mtgbbd?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_49")
              .get(uri07 + "/kraken/streams/cadu_romao?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_50")
              .get(uri07 + "/kraken/streams/yaya3_?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_51")
              .get(uri07 + "/kraken/streams/chauckster?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_52")
              .get(uri07 + "/kraken/streams/efropoker?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_53")
              .get(uri07 + "/kraken/streams/pvddr?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_54")
              .get(uri07 + "/kraken/streams/reiderrabbit?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_55")
              .get(uri07 + "/kraken/streams/death_snow?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_56")
              .get(uri07 + "/kraken/streams/owentmagic?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_57")
              .get(uri07 + "/kraken/streams/r0310?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_58")
              .get(uri07 + "/kraken/streams/luissalvatto?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_59")
              .get(uri07 + "/kraken/streams/andrewcuneo?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_60")
              .get(uri07 + "/kraken/streams/kbol_?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_61")
              .get(uri07 + "/kraken/streams/leearson?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_62")
              .get(uri07 + "/kraken/streams/sethmanfield?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_63")
              .get(uri07 + "/kraken/streams/kanister_mtg?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_64")
              .get(uri07 + "/kraken/streams/martinjuza?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_65")
              .get(uri07 + "/kraken/streams/jrolfmtg?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_66")
              .get(uri07 + "/kraken/streams/beena_oyaoya?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_67")
              .get(uri07 + "/kraken/streams/msigrist83?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_68")
              .get(uri07 + "/kraken/streams/matthewlnass?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_69")
              .get(uri07 + "/kraken/streams/HueyWJ?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_70")
              .get(uri07 + "/kraken/streams/lucas_esper_berthoud?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_71")
              .get(uri07 + "/kraken/streams/shahar_shenhar?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8)))
        .pause(5)
        .exec(http("request_72")
          .options("/spaces/ryplwhabvmmk/environments/master/entries?sys.id=64BOPvsAE5XO8rXTLQoQ6b&include=2")
          .headers(headers_72)
          .resources(http("request_73")
            .get("/spaces/ryplwhabvmmk/environments/master/entries?sys.id=64BOPvsAE5XO8rXTLQoQ6b&include=2")
            .headers(headers_73),
            http("request_74")
              .get(uri07 + "/kraken/streams/bens_MTG?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_75")
              .get(uri07 + "/kraken/streams/andreamengucci?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_76")
              .get(uri07 + "/kraken/streams/fffreakmtg?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_77")
              .get(uri07 + "/kraken/streams/mtgbbd?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_78")
              .get(uri07 + "/kraken/streams/g3rryt?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_79")
              .get(uri07 + "/kraken/streams/insaynehayne?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_80")
              .get(uri07 + "/kraken/streams/andrewcuneo?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_81")
              .get(uri07 + "/kraken/streams/chauckster?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_82")
              .get(uri07 + "/kraken/streams/urlich0?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_83")
              .get(uri07 + "/kraken/streams/javierdmagic?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_84")
              .get(uri07 + "/kraken/streams/jirock?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_85")
              .get(uri07 + "/kraken/streams/death_snow?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_86")
              .get(uri07 + "/kraken/streams/lucas_esper_berthoud?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_87")
              .get(uri07 + "/kraken/streams/martinjuza?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_88")
              .get(uri07 + "/kraken/streams/leearson?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_89")
              .get(uri07 + "/kraken/streams/kbol_?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_90")
              .get(uri07 + "/kraken/streams/msigrist83?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_91")
              .get(uri07 + "/kraken/streams/jrolfmtg?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_92")
              .get(uri07 + "/kraken/streams/cadu_romao?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_93")
              .get(uri07 + "/kraken/streams/luissalvatto?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_94")
              .get(uri07 + "/kraken/streams/owentmagic?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_95")
              .get(uri07 + "/kraken/streams/kanister_mtg?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_96")
              .get(uri07 + "/kraken/streams/reiderrabbit?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_97")
              .get(uri07 + "/kraken/streams/efropoker?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_98")
              .get(uri07 + "/kraken/streams/matthewlnass?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_99")
              .get(uri07 + "/kraken/streams/shahar_shenhar?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_100")
              .get(uri07 + "/kraken/streams/r0310?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_101")
              .get(uri07 + "/kraken/streams/sethmanfield?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_102")
              .get(uri07 + "/kraken/streams/yaya3_?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_103")
              .get(uri07 + "/kraken/streams/beena_oyaoya?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_104")
              .get(uri07 + "/kraken/streams/HueyWJ?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_105")
              .get(uri07 + "/kraken/streams/pvddr?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8)))
        .pause(2)
        .exec(http("request_106")
          .options("/spaces/ryplwhabvmmk/environments/master/entries?sys.id=7Ij4NAesYoadQaCZLYEN1D&include=2")
          .headers(headers_72)
          .resources(http("request_107")
            .get("/spaces/ryplwhabvmmk/environments/master/entries?sys.id=7Ij4NAesYoadQaCZLYEN1D&include=2")
            .headers(headers_73),
            http("request_108")
              .get(uri11 + "/?channel=reiderrabbit")
              .headers(headers_108),
            http("request_109")
              .get(uri03 + "/K1oAo3Go95w91jgUReICX/cd1704c9d8a91e7ded4337a53d5f14b4/photo-1513002433973-e0a181372d60"),
            http("request_110")
              .get(uri03 + "/6F9dv6oF35Ycat2FBdehgd/4fbf9419d68cd6620457eeb6401fed8a/photo-1534450094358-51abce6b6327"),
            http("request_111")
              .get(uri03 + "/4cPA8hpvQ6R0iuLxgQeYKa/3c587a1877e49f1b905a96e2f3ca22b1/photo-1548061435-d56a87bdd05a"),
            http("request_112")
              .get(uri03 + "/4zVzqWrVrtlddZ4vYdAbvk/db76c35b171b8596b4dd70caffe33cb1/photo-1549056572-75914d5d5fd4"),
            http("request_113")
              .get(uri07 + "/kraken/streams/andreamengucci?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_114")
              .get(uri07 + "/kraken/streams/fffreakmtg?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_115")
              .get(uri07 + "/kraken/streams/mtgbbd?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_116")
              .get(uri07 + "/kraken/streams/chauckster?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_117")
              .get(uri07 + "/kraken/streams/bens_MTG?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_118")
              .get(uri07 + "/kraken/streams/cadu_romao?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_119")
              .get(uri07 + "/kraken/streams/insaynehayne?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_120")
              .get(uri03 + "/1RxbEvyFL3WRryZWRLBd7y/cf5a6e7aaa3ff10a4818504478c58726/photo-1547496824-89cd1a35414d"),
            http("request_121")
              .get(uri07 + "/kraken/streams/efropoker?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_122")
              .get(uri07 + "/kraken/streams/andrewcuneo?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_123")
              .get(uri07 + "/kraken/streams/fffreakmtg?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_124")
              .get(uri07 + "/kraken/streams/mtgbbd?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_125")
              .get(uri07 + "/kraken/streams/bens_MTG?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_126")
              .get(uri07 + "/kraken/streams/chauckster?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_127")
              .get(uri07 + "/kraken/streams/insaynehayne?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_128")
              .get(uri07 + "/kraken/streams/cadu_romao?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_129")
              .get(uri07 + "/kraken/streams/andrewcuneo?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_130")
              .get(uri07 + "/kraken/streams/efropoker?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_131")
              .get(uri07 + "/kraken/streams/andreamengucci?client_id=68yl43z60syllq3xs59b7dsieaq2sm")
              .headers(headers_8),
            http("request_132")
              .get(uri14 + "")
              .headers(headers_132),
            http("request_133")
              .options(uri07 + "/kraken/user")
              .headers(headers_133),
            http("request_134")
              .options(uri07 + "/gql")
              .headers(headers_134),
            http("request_135")
              .options(uri07 + "/kraken/streams/reiderrabbit")
              .headers(headers_133),
            http("request_136")
              .options(uri07 + "/gql")
              .headers(headers_134),
            http("request_137")
              .options(uri07 + "/kraken/channels/reiderrabbit")
              .headers(headers_133),
            http("request_138")
              .options(uri07 + "/api/channels/reiderrabbit/access_token?need_https=true&oauth_token&platform=web&player_backend=mediaplayer&player_type=embed")
              .headers(headers_133),
            http("request_139")
              .options(uri07 + "/gql")
              .headers(headers_134),
            http("request_140")
              .options(uri07 + "/gql")
              .headers(headers_134),
            http("request_141")
              .get(uri07 + "/kraken/streams/reiderrabbit")
              .headers(headers_141),
            http("request_142")
              .get(uri07 + "/kraken/channels/reiderrabbit")
              .headers(headers_141),
            http("request_147")
              .get(uri07 + "/api/channels/reiderrabbit/access_token?need_https=true&oauth_token&platform=web&player_backend=mediaplayer&player_type=embed")
              .headers(headers_147),
            http("request_148")
              .options(uri05 + "")
              .headers(headers_148),
            http("request_150")
              .get(uri12 + "?domain=player.twitch.tv"),
            http("request_151")
              .get(uri15 + "?u=%7B%22type%22%3A%22channel%22%2C%22id%22%3A30967375%7D"),
            http("request_152")
              .get(uri09 + "")
              .headers(headers_152),
            http("request_153")
              .get(uri18 + "")
              .headers(headers_132),
            http("request_157")
              .post(uri16 + "")
              .headers(headers_157)
              .formParam("data", "W3siZXZlbnQiOiJleHBlcmltZW50X2JyYW5jaCIsInByb3BlcnRpZXMiOnsiY2xpZW50X3RpbWUiOjE1NTI0MjM2NzAuMjY1LCJkZXZpY2VfaWQiOiJFVVJlTjZBNTRLbU1TdHNONEN3bkVxcXVncHpmNDd3WSIsImV4cGVyaW1lbnRfaWQiOiI1ZmJiNjdhMC1iNGZmLTQ3NzUtYjgzNi1lOWEzNDhhODc0ODEiLCJleHBlcmltZW50X2dyb3VwIjoibm8iLCJwbGF0Zm9ybSI6IndlYiIsImV4cGVyaW1lbnRfdmVyc2lvbiI6MzAsImV4cGVyaW1lbnRfbmFtZSI6Ik5ldHdvcmsgUHJvZmlsZSBDb2xsZWN0aW9uIiwiZXhwZXJpbWVudF90eXBlIjoiZGV2aWNlX2lkIn19LHsiZXZlbnQiOiJleHBlcmltZW50X2JyYW5jaCIsInByb3BlcnRpZXMiOnsiY2xpZW50X3RpbWUiOjE1NTI0MjM2NzAuMjY1LCJkZXZpY2VfaWQiOiJFVVJlTjZBNTRLbU1TdHNONEN3bkVxcXVncHpmNDd3WSIsImV4cGVyaW1lbnRfaWQiOiI2YTI2MzBhNC1lZGM3LTRmMmEtOGNmZS1lNGRlNzVlYjBkOTgiLCJleHBlcmltZW50X2dyb3VwIjoiY29udHJvbCIsInBsYXRmb3JtIjoid2ViIiwiZXhwZXJpbWVudF92ZXJzaW9uIjozNzAxLCJleHBlcmltZW50X25hbWUiOiJydHFvcyIsImV4cGVyaW1lbnRfdHlwZSI6ImRldmljZV9pZCJ9fSx7ImV2ZW50IjoiZXhwZXJpbWVudF9icmFuY2giLCJwcm9wZXJ0aWVzIjp7ImNsaWVudF90aW1lIjoxNTUyNDIzNjcwLjI2NSwiZGV2aWNlX2lkIjoiRVVSZU42QTU0S21NU3RzTjRDd25FcXF1Z3B6ZjQ3d1kiLCJleHBlcmltZW50X2lkIjoiZTJmZWNiZDQtOThlNC00NWUwLWFhZDUtNjI0Y2M3MGQ2Yjg1IiwiZXhwZXJpbWVudF9ncm91cCI6InllcyIsInBsYXRmb3JtIjoid2ViIiwiZXhwZXJpbWVudF92ZXJzaW9uIjo1NDc4LCJleHBlcmltZW50X25hbWUiOiJ2aWRlb19lZGdlX3JlYXNzaWdubWVudCIsImV4cGVyaW1lbnRfdHlwZSI6ImRldmljZV9pZCJ9fSx7ImV2ZW50IjoiZXhwZXJpbWVudF9icmFuY2giLCJwcm9wZXJ0aWVzIjp7ImNsaWVudF90aW1lIjoxNTUyNDIzNjcwLjI2NSwiZGV2aWNlX2lkIjoiRVVSZU42QTU0S21NU3RzTjRDd25FcXF1Z3B6ZjQ3d1kiLCJleHBlcmltZW50X2lkIjoiN2NkZWU3MDEtMGFjMy00YjQ3LTk0ZDMtYjQ3YjNiNzA3ZGM4IiwiZXhwZXJpbWVudF9ncm91cCI6ImFjdGl2ZSIsInBsYXRmb3JtIjoid2ViIiwiZXhwZXJpbWVudF92ZXJzaW9uIjo1OTYwLCJleHBlcmltZW50X25hbWUiOiJuaWVsc2VuX2FuYWx5dGljcyIsImV4cGVyaW1lbnRfdHlwZSI6ImRldmljZV9pZCJ9fSx7ImV2ZW50IjoiZXhwZXJpbWVudF9icmFuY2giLCJwcm9wZXJ0aWVzIjp7ImNsaWVudF90aW1lIjoxNTUyNDIzNjcwLjI2NSwiZGV2aWNlX2lkIjoiRVVSZU42QTU0S21NU3RzTjRDd25FcXF1Z3B6ZjQ3d1kiLCJleHBlcmltZW50X2lkIjoiNzBjMDVjNzItY2NmZS00NjA0LTg5NWMtNDhmZjNmYzk4MTI4IiwiZXhwZXJpbWVudF9ncm91cCI6InNlbmQiLCJwbGF0Zm9ybSI6IndlYiIsImV4cGVyaW1lbnRfdmVyc2lvbiI6NTAzNCwiZXhwZXJpbWVudF9uYW1lIjoidW50cnVzdGVkX3RpZXJfMV9tZXRyaWNzIiwiZXhwZXJpbWVudF90eXBlIjoiZGV2aWNlX2lkIn19LHsiZXZlbnQiOiJleHBlcmltZW50X2JyYW5jaCIsInByb3BlcnRpZXMiOnsiY2xpZW50X3RpbWUiOjE1NTI0MjM2NzAuMjY1LCJkZXZpY2VfaWQiOiJFVVJlTjZBNTRLbU1TdHNONEN3bkVxcXVncHpmNDd3WSIsImV4cGVyaW1lbnRfaWQiOiI3NDJiNzUzMS04ZjVjLTRjNjItOTA5OS03YjJhNjAwNDhhYjIiLCJleHBlcmltZW50X2dyb3VwIjoiY29udHJvbCIsInBsYXRmb3JtIjoid2ViIiwiZXhwZXJpbWVudF92ZXJzaW9uIjo1ODg1LCJleHBlcmltZW50X25hbWUiOiJwbGF5ZXJfY3MiLCJleHBlcmltZW50X3R5cGUiOiJkZXZpY2VfaWQifX0seyJldmVudCI6ImV4cGVyaW1lbnRfYnJhbmNoIiwicHJvcGVydGllcyI6eyJjbGllbnRfdGltZSI6MTU1MjQyMzY3MC4yNjUsImRldmljZV9pZCI6IkVVUmVONkE1NEttTVN0c040Q3duRXFxdWdwemY0N3dZIiwiZXhwZXJpbWVudF9pZCI6ImIyNTNmMDYwLTE5ZmMtNDUzOS05OGUyLTM5MWE1NTM1NDc0MSIsImV4cGVyaW1lbnRfZ3JvdXAiOiJ0cmVhdG1lbnQiLCJwbGF0Zm9ybSI6IndlYiIsImV4cGVyaW1lbnRfdmVyc2lvbiI6NTg3MCwiZXhwZXJpbWVudF9uYW1lIjoidmFlc193YXZlXzMiLCJleHBlcmltZW50X3R5cGUiOiJkZXZpY2VfaWQifX0seyJldmVudCI6ImV4cGVyaW1lbnRfYnJhbmNoIiwicHJvcGVydGllcyI6eyJjbGllbnRfdGltZSI6MTU1MjQyMzY3MC4yODUsImRldmljZV9pZCI6IkVVUmVONkE1NEttTVN0c040Q3duRXFxdWdwemY0N3dZIiwiZXhwZXJpbWVudF9pZCI6IjZhNTVhODgxLTJlNDMtNGUxYi05ZmYyLWRlODkxNmQ2ZjgwZSIsImV4cGVyaW1lbnRfZ3JvdXAiOiJjb250cm9sIiwicGxhdGZvcm0iOiJ3ZWIiLCJleHBlcmltZW50X3ZlcnNpb24iOjU5MTAsImV4cGVyaW1lbnRfbmFtZSI6IlZQMDkgV2ViIiwiZXhwZXJpbWVudF90eXBlIjoiZGV2aWNlX2lkIn19LHsiZXZlbnQiOiJleHBlcmltZW50X2JyYW5jaCIsInByb3BlcnRpZXMiOnsiY2xpZW50X3RpbWUiOjE1NTI0MjM2NzAuMjg1LCJkZXZpY2VfaWQiOiJFVVJlTjZBNTRLbU1TdHNONEN3bkVxcXVncHpmNDd3WSIsImV4cGVyaW1lbnRfaWQiOiJlYzcwYmQwOC1kYmM4LTRmNDgtOWY2MC1kMDM1ZmVjM2ViMjAiLCJleHBlcmltZW50X2dyb3VwIjoiMi45LjIiLCJwbGF0Zm9ybSI6IndlYiIsImV4cGVyaW1lbnRfdmVyc2lvbiI6NjAwMCwiZXhwZXJpbWVudF9uYW1lIjoiVHdpbGlnaHQgUGxheWVyIENvcmUgRGlzdHJpYnV0aW9uIChHbG9iYWwpIiwiZXhwZXJpbWVudF90eXBlIjoiZGV2aWNlX2lkIn19LHsiZXZlbnQiOiJleHBlcmltZW50X2JyYW5jaCIsInByb3BlcnRpZXMiOnsiY2xpZW50X3RpbWUiOjE1NTI0MjM2NzAuMjg1LCJkZXZpY2VfaWQiOiJFVVJlTjZBNTRLbU1TdHNONEN3bkVxcXVncHpmNDd3WSIsImV4cGVyaW1lbnRfaWQiOiI0OTA4MzU5NS04MGQ0LTRjMTMtOTNhMi0yMGE2MDViMzMxOGUiLCJleHBlcmltZW50X2dyb3VwIjoid2FzbSIsInBsYXRmb3JtIjoid2ViIiwiZXhwZXJpbWVudF92ZXJzaW9uIjo0MTM5LCJleHBlcmltZW50X25hbWUiOiJQbGF5ZXIgQ29yZSBXQVNNIGV4cGVyaW1lbnQiLCJleHBlcmltZW50X3R5cGUiOiJkZXZpY2VfaWQifX0seyJldmVudCI6ImV4cGVyaW1lbnRfYnJhbmNoIiwicHJvcGVydGllcyI6eyJjbGllbnRfdGltZSI6MTU1MjQyMzY3MS4yMjIsImRldmljZV9pZCI6IkVVUmVONkE1NEttTVN0c040Q3duRXFxdWdwemY0N3dZIiwiZXhwZXJpbWVudF9pZCI6Ijg5MzI4MzEwLTJhZTItNDQ4Yi05Y2Y2LWI4MDFiMjA0NzBmNyIsImV4cGVyaW1lbnRfZ3JvdXAiOiJjb250cm9sIiwicGxhdGZvcm0iOiJ3ZWIiLCJleHBlcmltZW50X3ZlcnNpb24iOjU1OTYsImV4cGVyaW1lbnRfbmFtZSI6InBsYXllcl93YXRjaF9hbm9uX25vdGlmaWNhdGlvbnMiLCJleHBlcmltZW50X3R5cGUiOiJkZXZpY2VfaWQifX0seyJldmVudCI6ImV4cGVyaW1lbnRfYnJhbmNoIiwicHJvcGVydGllcyI6eyJjbGllbnRfdGltZSI6MTU1MjQyMzY3MS4yMjYsImRldmljZV9pZCI6IkVVUmVONkE1NEttTVN0c040Q3duRXFxdWdwemY0N3dZIiwiZXhwZXJpbWVudF9pZCI6ImJkOTIzNGZjLTNjNDAtNDVmNi1hNTQ0LTg2ODQ3ODc0NGJhNyIsImV4cGVyaW1lbnRfZ3JvdXAiOiJkaXNhYmxlZCIsInBsYXRmb3JtIjoid2ViIiwiZXhwZXJpbWVudF92ZXJzaW9uIjo1MTM1LCJleHBlcmltZW50X25hbWUiOiJmZWF0dXJlZF9jb2xsZWN0aW9uX2Rpc2FibGUiLCJleHBlcmltZW50X3R5cGUiOiJkZXZpY2VfaWQifX1d"),
            http("request_158")
              .get(uri06 + "/ysWRN3BqG3U"),
            http("request_159")
              .get(uri08 + "/photo-1552256203-c5863f355f44?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjF9"),
            http("request_160")
              .get(uri08 + "/photo-1552181903-a6af3a3d159d?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjF9"),
            http("request_161")
              .get(uri08 + "/photo-1494828660964-d9fe90d88f97?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjF9"),
            http("request_162")
              .get(uri06 + "/7xemAmqHhLc"),
            http("request_163")
              .get(uri08 + "/photo-1482236416769-247f629d4a34?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjF9"),
            http("request_164")
              .get(uri08 + "/photo-1552130958-1fcaee3e1b9e?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&ixid=eyJhcHBfaWQiOjF9")))


    }
  }






  // setup the load profile
  // example command line: ./gradlew gatlingRun-simulations.RuntimeParameters -DUSERS=10 -DRAMP_DURATION=5 -DDURATION=30
  val scn = scenario("Esports")

    .forever() { // add in the forever() method - users now loop forever
      exec(postSpecificOgreID())

    }
  setUp(
    scn.inject(
      nothingFor(5 seconds),
      rampUsers(userCount) over ( 5 seconds))

      .protocols(httpConf))


    .maxDuration(testDuration)
}


