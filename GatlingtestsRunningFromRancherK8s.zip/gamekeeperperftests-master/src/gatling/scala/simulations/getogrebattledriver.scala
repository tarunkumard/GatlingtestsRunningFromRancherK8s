package simulations

import baseConfig.BaseSimulation
import com.jayway.jsonpath.JsonPath
import io.gatling.core.Predef._
import io.gatling.http.Predef._

import scala.concurrent.duration.DurationInt
import scala.io.Source


class getogrebattledriver extends BaseSimulation {

  val uri03 = "https://api.platform.wizards.com"

  val headers_0 = Map(
    "Accept" -> "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
    "Accept-Encoding" -> "gzip, deflate, br",
    "Accept-Language" -> "en-GB,en-US;q=0.9,en;q=0.8",
    "Upgrade-Insecure-Requests" -> "1",
    "User-Agent" -> "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36")

  val headers_1 = Map("User-Agent" -> "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36")

  val headers_7 = Map(
    "Access-Control-Request-Headers" -> "authorization",
    "Access-Control-Request-Method" -> "POST",
    "Origin" -> "https://api.tabletop-stage.tiamat-origin.cloud",
    "User-Agent" -> "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36")

  val headers_8 = Map(
    "Accept" -> "application/json, text/plain, */*",
    "Content-Type" -> "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin" -> "https://api.tabletop-stage.tiamat-origin.cloud",
    "User-Agent" -> "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.109 Safari/537.36")

  val headers_10 = Map("Content-Type" -> "application/json","Authorization" -> "${token_type} + ${access_token}" )

  val usersDataSource=jsonFile("/opt/src/gatling/resources/data/input-post.json").circular
  val nameDataSource=jsonFile("/opt/src/gatling/resources/data/input-get.json").random
  var idNumbers=(21 to 33).iterator


  private def getProperty(propertyName: String, defaultValue: String) = {
    Option(System.getenv(propertyName))
      .orElse(Option(System.getProperty(propertyName)))
      .getOrElse(defaultValue)
  }
  // now specify the properties
  //def userCount: Int = getProperty("USERS", "100").toInt

  val source: String = Source.fromFile("/opt/src/gatling/resources/data/input-post.json").getLines.mkString
  def userCount: Int  = JsonPath.parse(source).read("$.[0].user")
  def testDuration: Int  = JsonPath.parse(source).read("$.[0].testDuration")
  def rampDuration: Int  = JsonPath.parse(source).read("$.[0].rampDuration")


  // print out the properties at the start of the test
  before {
    println(s"Running test with ${userCount} users")
    println(s"Ramping users over ${rampDuration} seconds")
    println(s"Total Test duration: ${testDuration} seconds")
  }

  def getNextOrgId()=
  {
    if(!idNumbers.hasNext)
      idNumbers=(21 to 33).iterator
    Map("orgId"->idNumbers.next())
  }

  val customFeeder=Iterator.continually(getNextOrgId())

  def getSpecificOgreID()={
    repeat(66000){
      exec(flushHttpCache)
      feed(usersDataSource)
        .feed(customFeeder).
        exec(http("GetSpecificOgreBattleDriverOrgId")
          .get("${url}"+"${orgId}")


          .check(status.is(200))//checkforaspecificstatus
          .check(jsonPath(path="$.name").saveAs(key="name")))//checkforaspecificstatus
        .exec{session=>println(session);session}//parameterfortheorgIdgoeshere
        .pause(1)


    }
  }

  def postSpecificOgreID()={
    repeat(990000000){


      exec(flushHttpCache)
      feed(nameDataSource)
        .exec(http("PostRequestPerformanceTestingOgreBattleDriver")
          .post("https://api.tabletop-stage.tiamat-origin.cloud/dev/ogre-battledriver/Organizations")
          .headers(headers_10)
          .body(StringBody(session =>
            s"""
               |{
               |  "name": "PerfTest",
               |  "latitude": 66.256538,
               |  "longitude": -95.934502,
               |  "phoneNumber": "555-555-5555",
               |  "emailAddress": "perftest1@perftest1.com",
               |  "website": "https://perftest1",
               |  "streetLine1": "123 perftest1.",
               |  "streetLine2": "Ste 400",
               |  "city": "Omaha",
               |  "state": "NE",
               |  "zipCode": "98002"
               |}
         """.stripMargin)).asJSON

          .check(status.in(200,201))//checkforaspecificstatus
          .check(jsonPath(path="$.name").saveAs(key="name")))//checkforaspecificstatus
        .exec{session=>println(session);session}//parameterfortheorgIdgoeshere
        .pause(1)

    }
  }

  // add a scenario
  val scenario1  = scenario("Ogre Battle Driver Get Orgs ")
    .forever() { // add in the forever() method - users now loop forever

      exec(getSpecificOgreID())
    }

  val scenario2 = scenario("Ogre Battle Driver Post Orgs ")
    .exec(http("Event-Reservations-Web-Image-Login")
      .get("https://api.tabletop-stage.tiamat-origin.cloud/dev/event-reservations-web/img/loading.dfbfd678.svg")
      .headers(headers_1)
      .resources(http("Http Header Token Authentication Url")
        .options(uri03 + "/auth/oauth/token")
        .headers(headers_7),
        http("Token Generation Url For Post")
          .post(uri03 + "/auth/oauth/token")
          .headers(headers_8)
          .formParam("grant_type", "password")
          .formParam("username", "TableTopEng@wizards.com")
          .formParam("password", "fJC2RuVdvmHB")
          .basicAuth("ikrwugh3871ghw8rgn7q83gh","NbnEEqmDLSfno315o87ghFGYr3jybtzbi76sr")
          .check(jsonPath("$.access_token").exists.saveAs("access_token"))
          .check(jsonPath("$.token_type").exists.saveAs("token_type"))





      ))
    .forever() { // add in the forever() method - users now loop forever
      exec(postSpecificOgreID())

    }

  // setup the load profile
  // example command line: ./gradlew gatlingRun-simulations.RuntimeParameters -DUSERS=10 -DRAMP_DURATION=5 -DDURATION=30
  setUp(
    scenario1.inject(
      nothingFor(5 seconds),
      rampUsers(userCount) over (rampDuration))

    .protocols(httpConf),
  scenario2.inject(
    nothingFor(5 seconds),
    rampUsers(userCount) over (rampDuration))
    .protocols(httpConf))


    .maxDuration(testDuration)
}

