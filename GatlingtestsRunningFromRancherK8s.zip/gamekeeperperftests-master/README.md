Perf Test code for Below GameKeeper methods

A) Create EventRound GameKeeper
B) Create Round Result
C) Get Current Round